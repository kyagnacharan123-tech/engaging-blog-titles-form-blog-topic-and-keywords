-- Database Schema for AI Blog Title Generator
-- PostgreSQL Database Setup

-- Create database
CREATE DATABASE blog_titles_db;

-- Connect to database
\c blog_titles_db;

-- Create titles table
CREATE TABLE titles (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    topic VARCHAR(255) NOT NULL,
    keywords TEXT,
    style VARCHAR(50) NOT NULL CHECK (style IN ('how-to', 'list', 'question')),
    length INTEGER NOT NULL,
    engagement_score INTEGER NOT NULL CHECK (engagement_score >= 0 AND engagement_score <= 100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create topics table
CREATE TABLE topics (
    id SERIAL PRIMARY KEY,
    topic VARCHAR(255) UNIQUE NOT NULL,
    usage_count INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create users table (optional for multi-user support)
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create user_titles junction table (optional)
CREATE TABLE user_titles (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    title_id INTEGER REFERENCES titles(id) ON DELETE CASCADE,
    is_favorite BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, title_id)
);

-- Create indexes for better query performance
CREATE INDEX idx_titles_topic ON titles(topic);
CREATE INDEX idx_titles_style ON titles(style);
CREATE INDEX idx_titles_engagement ON titles(engagement_score);
CREATE INDEX idx_titles_created ON titles(created_at);
CREATE INDEX idx_topics_topic ON topics(topic);

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for titles table
CREATE TRIGGER update_titles_updated_at
    BEFORE UPDATE ON titles
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Create view for statistics
CREATE VIEW title_statistics AS
SELECT 
    COUNT(*) as total_titles,
    COUNT(DISTINCT topic) as unique_topics,
    ROUND(AVG(engagement_score), 2) as avg_engagement_score,
    MAX(created_at) as last_generated
FROM titles;

-- Create view for style distribution
CREATE VIEW style_distribution AS
SELECT 
    style,
    COUNT(*) as count,
    ROUND(AVG(engagement_score), 2) as avg_score,
    ROUND((COUNT(*) * 100.0 / (SELECT COUNT(*) FROM titles)), 2) as percentage
FROM titles
GROUP BY style
ORDER BY count DESC;

-- Create view for top topics
CREATE VIEW top_topics AS
SELECT 
    t.topic,
    t.usage_count,
    COUNT(ti.id) as title_count,
    ROUND(AVG(ti.engagement_score), 2) as avg_score
FROM topics t
LEFT JOIN titles ti ON t.topic = ti.topic
GROUP BY t.id, t.topic, t.usage_count
ORDER BY t.usage_count DESC
LIMIT 10;

-- Insert sample data (optional)
INSERT INTO titles (title, topic, keywords, style, length, engagement_score) VALUES
('How to Master AI in 2026: A Complete Guide', 'artificial intelligence', 'machine learning, AI trends', 'how-to', 43, 85),
('10 Essential AI Tools Every Developer Needs', 'artificial intelligence', 'development, tools', 'list', 41, 78),
('What is the Future of AI? Expert Insights', 'artificial intelligence', 'future, predictions', 'question', 42, 82);

-- Grant permissions (adjust username as needed)
-- GRANT ALL PRIVILEGES ON DATABASE blog_titles_db TO your_username;
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO your_username;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO your_username;

-- Create stored procedure for adding titles
CREATE OR REPLACE FUNCTION add_title(
    p_title VARCHAR,
    p_topic VARCHAR,
    p_keywords TEXT,
    p_style VARCHAR,
    p_length INTEGER,
    p_engagement_score INTEGER
)
RETURNS INTEGER AS $$
DECLARE
    v_title_id INTEGER;
BEGIN
    -- Insert title
    INSERT INTO titles (title, topic, keywords, style, length, engagement_score)
    VALUES (p_title, p_topic, p_keywords, p_style, p_length, p_engagement_score)
    RETURNING id INTO v_title_id;
    
    -- Update or insert topic
    INSERT INTO topics (topic, usage_count)
    VALUES (p_topic, 1)
    ON CONFLICT (topic) 
    DO UPDATE SET usage_count = topics.usage_count + 1;
    
    RETURN v_title_id;
END;
$$ LANGUAGE plpgsql;

-- Create stored procedure for getting filtered titles
CREATE OR REPLACE FUNCTION get_titles(
    p_style VARCHAR DEFAULT NULL,
    p_min_score INTEGER DEFAULT NULL,
    p_limit INTEGER DEFAULT 10
)
RETURNS TABLE (
    id INTEGER,
    title VARCHAR,
    topic VARCHAR,
    style VARCHAR,
    length INTEGER,
    engagement_score INTEGER,
    created_at TIMESTAMP
) AS $$
BEGIN
    RETURN QUERY
    SELECT t.id, t.title, t.topic, t.style, t.length, t.engagement_score, t.created_at
    FROM titles t
    WHERE 
        (p_style IS NULL OR t.style = p_style) AND
        (p_min_score IS NULL OR t.engagement_score >= p_min_score)
    ORDER BY t.created_at DESC
    LIMIT p_limit;
END;
$$ LANGUAGE plpgsql;

-- Usage examples:
-- Add a title:
-- SELECT add_title('My Title', 'My Topic', 'keyword1, keyword2', 'how-to', 45, 75);

-- Get filtered titles:
-- SELECT * FROM get_titles('how-to', 70, 5);

-- Get statistics:
-- SELECT * FROM title_statistics;

-- Get style distribution:
-- SELECT * FROM style_distribution;

-- Get top topics:
-- SELECT * FROM top_topics;

-- Comments
COMMENT ON TABLE titles IS 'Stores all generated blog titles';
COMMENT ON TABLE topics IS 'Tracks unique topics and their usage';
COMMENT ON VIEW title_statistics IS 'Aggregate statistics for all titles';
COMMENT ON VIEW style_distribution IS 'Distribution of title styles with scores';
COMMENT ON VIEW top_topics IS 'Most frequently used topics';
