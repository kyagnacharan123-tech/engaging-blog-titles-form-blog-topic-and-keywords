# Testing Guide for AI Blog Title Generator

## Testing Overview

This document covers all testing procedures for the AI Blog Title Generator application.

## Test Categories

1. Frontend Testing
2. Backend API Testing
3. Database Testing
4. AI Integration Testing
5. User Experience Testing
6. Performance Testing
7. Security Testing

---

## 1. Frontend Testing

### 1.1 UI Component Tests

#### Test Case 1: Page Load
**Objective:** Verify page loads correctly
**Steps:**
1. Open index.html in browser
2. Check all elements are visible
3. Verify no console errors

**Expected Results:**
- ✓ Header displays with title and subtitle
- ✓ Input form is visible
- ✓ Statistics show 0 initially
- ✓ No JavaScript errors in console

#### Test Case 2: Form Validation
**Objective:** Verify input validation works
**Steps:**
1. Click "Generate Titles" with empty topic
2. Observe error message
3. Enter topic and submit

**Expected Results:**
- ✓ Error message appears for empty topic
- ✓ Error message is clear and visible
- ✓ Form submits with valid topic

#### Test Case 3: Style Selection
**Objective:** Verify style selector works
**Steps:**
1. Click each style option (How-to, Lists, Questions, Mixed)
2. Verify visual feedback
3. Check selected value

**Expected Results:**
- ✓ Only one style can be selected at a time
- ✓ Selected style is highlighted
- ✓ Hover effects work

#### Test Case 4: Title Generation
**Objective:** Verify titles generate and display
**Steps:**
1. Enter topic: "artificial intelligence"
2. Select style: "How-to"
3. Click "Generate Titles"
4. Wait for results

**Expected Results:**
- ✓ Loading animation appears
- ✓ Loading takes 1-3 seconds
- ✓ 10 titles are displayed
- ✓ Each title has metadata (length, style, score)
- ✓ Titles animate in sequentially

#### Test Case 5: Copy Functionality
**Objective:** Verify copy to clipboard works
**Steps:**
1. Generate titles
2. Click copy button on any title
3. Paste in text editor

**Expected Results:**
- ✓ Copy button shows "✓ Copied!" feedback
- ✓ Title is correctly copied to clipboard
- ✓ Button reverts after 2 seconds

#### Test Case 6: Filters
**Objective:** Verify filter controls work
**Steps:**
1. Generate titles with "Mixed" style
2. Use style filter: select "How-to"
3. Use engagement filter: select "High"
4. Reset filters to "All"

**Expected Results:**
- ✓ Only matching titles are displayed
- ✓ Multiple filters work together
- ✓ Filter count updates
- ✓ "All" shows all titles

#### Test Case 7: Statistics
**Objective:** Verify statistics update correctly
**Steps:**
1. Note initial statistics (should be 0)
2. Generate titles once
3. Check statistics update
4. Generate more titles
5. Verify stats increment

**Expected Results:**
- ✓ Total Generated increases by 10
- ✓ Topics count increases by 1 (for unique topics)
- ✓ Average score calculates correctly
- ✓ Stats animate when updating

#### Test Case 8: Clear Results
**Objective:** Verify clear functionality works
**Steps:**
1. Generate some titles
2. Click "Clear Results"
3. Confirm dialog
4. Check database

**Expected Results:**
- ✓ Confirmation dialog appears
- ✓ All titles are removed
- ✓ Statistics reset to 0
- ✓ LocalStorage is cleared

### 1.2 Responsive Design Tests

#### Test Case 9: Mobile View
**Objective:** Verify mobile responsiveness
**Steps:**
1. Open in Chrome DevTools
2. Toggle device toolbar
3. Test various screen sizes:
   - iPhone 12 (390x844)
   - iPad (768x1024)
   - Desktop (1920x1080)

**Expected Results:**
- ✓ Layout adapts to screen size
- ✓ No horizontal scrolling
- ✓ Buttons stack on mobile
- ✓ Text is readable
- ✓ Touch targets are adequate (44x44px minimum)

#### Test Case 10: Browser Compatibility
**Objective:** Verify cross-browser support
**Browsers to Test:**
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

**Expected Results:**
- ✓ All features work in each browser
- ✓ Styling is consistent
- ✓ No browser-specific errors

---

## 2. Backend API Testing

### 2.1 API Endpoint Tests

#### Test Case 11: Generate Endpoint
**Method:** POST /api/generate
**Request Body:**
```json
{
  "topic": "machine learning",
  "keywords": "AI, algorithms",
  "style": "how-to"
}
```

**Expected Response:**
```json
{
  "success": true,
  "titles": [/* 10 title objects */],
  "stats": {
    "totalGenerated": 10,
    "totalTopics": 1,
    "avgScore": 75
  }
}
```

**Test Steps:**
```bash
curl -X POST http://localhost:3000/api/generate \
  -H "Content-Type: application/json" \
  -d '{"topic":"machine learning","style":"how-to"}'
```

**Validations:**
- ✓ Status code: 200
- ✓ Returns exactly 10 titles
- ✓ Each title has required fields
- ✓ Response time < 5 seconds

#### Test Case 12: Get Titles Endpoint
**Method:** GET /api/titles
**Query Parameters:** ?style=list&limit=5

**Expected Response:**
```json
{
  "success": true,
  "titles": [/* filtered titles */],
  "count": 5
}
```

**Test Steps:**
```bash
curl http://localhost:3000/api/titles?style=list&limit=5
```

**Validations:**
- ✓ Status code: 200
- ✓ Returns filtered results
- ✓ Respects limit parameter
- ✓ Response time < 1 second

#### Test Case 13: Get Stats Endpoint
**Method:** GET /api/stats

**Test Steps:**
```bash
curl http://localhost:3000/api/stats
```

**Expected Response:**
```json
{
  "success": true,
  "stats": {
    "totalGenerated": 50,
    "totalTopics": 10,
    "avgScore": 78
  }
}
```

**Validations:**
- ✓ Status code: 200
- ✓ Statistics are accurate
- ✓ Response time < 500ms

#### Test Case 14: Clear Endpoint
**Method:** DELETE /api/clear

**Test Steps:**
```bash
curl -X DELETE http://localhost:3000/api/clear
```

**Validations:**
- ✓ Status code: 200
- ✓ Database is cleared
- ✓ Stats reset to 0

#### Test Case 15: Health Check
**Method:** GET /api/health

**Test Steps:**
```bash
curl http://localhost:3000/api/health
```

**Expected Response:**
```json
{
  "status": "healthy",
  "timestamp": "2026-01-30T...",
  "version": "1.0.0"
}
```

### 2.2 Error Handling Tests

#### Test Case 16: Missing Required Fields
**Request:**
```json
{
  "keywords": "test"
}
```

**Expected Response:**
```json
{
  "error": "Topic is required"
}
```
Status: 400

#### Test Case 17: Invalid Style
**Request:**
```json
{
  "topic": "test",
  "style": "invalid-style"
}
```

**Expected:** Server handles gracefully, defaults to valid style

#### Test Case 18: API Timeout
**Scenario:** Simulate slow AI API
**Expected:** Fallback to template generation after timeout

---

## 3. Database Testing

### 3.1 LocalStorage Tests

#### Test Case 19: Data Persistence
**Steps:**
1. Generate titles
2. Close browser
3. Reopen application
4. Check data is restored

**Expected:**
- ✓ Previous titles are loaded
- ✓ Statistics are preserved
- ✓ No data loss

#### Test Case 20: Storage Limits
**Steps:**
1. Generate titles multiple times (100+ generations)
2. Check performance
3. Verify storage size

**Expected:**
- ✓ Application handles large datasets
- ✓ No performance degradation
- ✓ Storage size is reasonable (<5MB)

### 3.2 PostgreSQL Tests (if using backend)

#### Test Case 21: CRUD Operations
**Create:**
```sql
SELECT add_title('Test Title', 'Test Topic', 'keywords', 'how-to', 45, 80);
```

**Read:**
```sql
SELECT * FROM get_titles('how-to', 70, 10);
```

**Update:**
```sql
UPDATE titles SET engagement_score = 90 WHERE id = 1;
```

**Delete:**
```sql
DELETE FROM titles WHERE id = 1;
```

#### Test Case 22: Indexes Performance
**Steps:**
1. Insert 10,000 titles
2. Run query with indexes
3. Run query without indexes
4. Compare performance

**Expected:**
- ✓ Indexed queries are significantly faster
- ✓ Query time < 100ms with indexes

---

## 4. AI Integration Testing

### 4.1 Claude API Tests

#### Test Case 23: AI Generation Quality
**Topic:** "artificial intelligence"
**Style:** "how-to"

**Quality Checks:**
- ✓ Titles are relevant to topic
- ✓ Titles follow selected style
- ✓ No duplicate titles
- ✓ Proper grammar and spelling
- ✓ SEO-friendly structure
- ✓ Varied lengths (40-70 characters)

#### Test Case 24: Keyword Integration
**Topic:** "healthy eating"
**Keywords:** "nutrition, diet, wellness"

**Validations:**
- ✓ Keywords appear in titles
- ✓ Natural keyword integration
- ✓ Not keyword-stuffed

#### Test Case 25: Style Accuracy
**Generate 10 titles for each style:**
- How-to: Should contain "How to", "Guide", "Tutorial"
- Lists: Should have numbers (5, 10, 15, etc.)
- Questions: Should end with "?"

#### Test Case 26: Fallback System
**Steps:**
1. Disconnect internet
2. Try generating titles
3. Verify fallback works

**Expected:**
- ✓ Template-based generation activates
- ✓ 10 titles are still generated
- ✓ User is not blocked

---

## 5. User Experience Testing

### 5.1 Usability Tests

#### Test Case 27: First-Time User
**Scenario:** User has never used the app
**Steps:**
1. Open application
2. Try to generate titles without instructions
3. Note any confusion points

**Success Criteria:**
- ✓ User can generate titles in < 2 minutes
- ✓ No help documentation needed
- ✓ Clear call-to-action
- ✓ Helpful error messages

#### Test Case 28: Loading Feedback
**Steps:**
1. Generate titles
2. Observe loading state
3. Note user feedback

**Expected:**
- ✓ Loading indicator is clear
- ✓ User knows process is working
- ✓ Loading time feels reasonable
- ✓ No confusion about state

#### Test Case 29: Result Satisfaction
**Steps:**
1. Generate titles for various topics
2. Evaluate title quality
3. Check diversity

**Success Criteria:**
- ✓ At least 8/10 titles are usable
- ✓ Good variety in approaches
- ✓ Professional quality
- ✓ SEO optimized

---

## 6. Performance Testing

### 6.1 Load Tests

#### Test Case 30: Concurrent Users
**Tools:** Apache Bench or similar
**Command:**
```bash
ab -n 100 -c 10 http://localhost:3000/api/generate \
  -p data.json -T application/json
```

**Metrics:**
- ✓ Requests per second > 10
- ✓ Average response time < 3s
- ✓ No failed requests
- ✓ Server doesn't crash

#### Test Case 31: Database Performance
**Steps:**
1. Insert 10,000 titles
2. Run queries
3. Measure response times

**Expected:**
- ✓ Queries return in < 100ms
- ✓ No memory leaks
- ✓ Consistent performance

### 6.2 Frontend Performance

#### Test Case 32: Page Load Time
**Tools:** Lighthouse, PageSpeed Insights

**Metrics:**
- ✓ First Contentful Paint < 1.5s
- ✓ Time to Interactive < 3s
- ✓ Performance score > 90
- ✓ Accessibility score > 95

---

## 7. Security Testing

### 7.1 Input Validation

#### Test Case 33: SQL Injection
**Input:** `'; DROP TABLE titles; --`
**Expected:** Input is sanitized, no SQL executed

#### Test Case 34: XSS Attacks
**Input:** `<script>alert('XSS')</script>`
**Expected:** Script is escaped, not executed

#### Test Case 35: API Key Exposure
**Check:**
- ✓ API keys not in client-side code
- ✓ API keys in environment variables
- ✓ No keys in version control

### 7.2 Authentication (if implemented)

#### Test Case 36: Unauthorized Access
**Steps:**
1. Try accessing API without auth
2. Check response

**Expected:**
- ✓ 401 Unauthorized
- ✓ Helpful error message

---

## Test Execution Checklist

### Before Release:
- [ ] All frontend tests pass
- [ ] All API tests pass
- [ ] Database tests pass
- [ ] AI integration works
- [ ] Performance is acceptable
- [ ] Security vulnerabilities addressed
- [ ] Browser compatibility verified
- [ ] Mobile responsiveness confirmed
- [ ] Documentation is complete
- [ ] Deployment guide tested

### Regression Testing:
Run after any code changes:
- [ ] Core functionality works
- [ ] No new bugs introduced
- [ ] Performance hasn't degraded
- [ ] API responses unchanged

---

## Automated Testing (Future Enhancement)

Consider implementing:

### Jest for Unit Tests
```javascript
describe('TitleGenerator', () => {
  test('generates 10 titles', async () => {
    const titles = await generator.generateTitles('AI', null, 'how-to');
    expect(titles).toHaveLength(10);
  });
});
```

### Cypress for E2E Tests
```javascript
describe('Title Generation', () => {
  it('should generate titles', () => {
    cy.visit('http://localhost:3000');
    cy.get('#topic').type('artificial intelligence');
    cy.get('#generateBtn').click();
    cy.get('.title-item').should('have.length', 10);
  });
});
```

---

## Reporting Bugs

When reporting issues, include:
1. **Steps to reproduce**
2. **Expected behavior**
3. **Actual behavior**
4. **Screenshots** (if applicable)
5. **Browser/OS information**
6. **Console errors**

---

## Test Results Template

```
Test Date: YYYY-MM-DD
Tester: [Name]
Environment: [Development/Staging/Production]

Test Case ID | Status | Notes
-------------|--------|-------
TC-01        | PASS   | -
TC-02        | FAIL   | Error message unclear
TC-03        | PASS   | -
...

Overall Status: [PASS/FAIL]
Critical Issues: [Count]
Major Issues: [Count]
Minor Issues: [Count]
```

---

**Remember:** Testing is continuous. Run tests regularly and especially before deploying to production!
