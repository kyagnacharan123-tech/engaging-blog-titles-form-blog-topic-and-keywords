// Database simulation using localStorage
class TitleDatabase {
    constructor() {
        this.dbName = 'blogTitleDB';
        this.init();
    }

    init() {
        if (!localStorage.getItem(this.dbName)) {
            localStorage.setItem(this.dbName, JSON.stringify({
                titles: [],
                topics: [],
                stats: {
                    totalGenerated: 0,
                    totalTopics: 0,
                    avgScore: 0
                }
            }));
        }
    }

    getData() {
        return JSON.parse(localStorage.getItem(this.dbName));
    }

    saveData(data) {
        localStorage.setItem(this.dbName, JSON.stringify(data));
    }

    addTitle(titleData) {
        const data = this.getData();
        titleData.id = Date.now() + Math.random();
        titleData.timestamp = new Date().toISOString();
        data.titles.push(titleData);
        
        // Update stats
        data.stats.totalGenerated = data.titles.length;
        
        // Add unique topics
        if (!data.topics.includes(titleData.topic)) {
            data.topics.push(titleData.topic);
            data.stats.totalTopics = data.topics.length;
        }
        
        // Calculate average score
        const totalScore = data.titles.reduce((sum, t) => sum + t.engagementScore, 0);
        data.stats.avgScore = Math.round(totalScore / data.titles.length);
        
        this.saveData(data);
        return titleData;
    }

    getTitles(filter = {}) {
        const data = this.getData();
        let titles = data.titles;
        
        if (filter.style && filter.style !== 'all') {
            titles = titles.filter(t => t.style === filter.style);
        }
        
        if (filter.engagement && filter.engagement !== 'all') {
            titles = titles.filter(t => this.getEngagementLevel(t.engagementScore) === filter.engagement);
        }
        
        return titles;
    }

    getStats() {
        return this.getData().stats;
    }

    clearAll() {
        localStorage.removeItem(this.dbName);
        this.init();
    }

    getEngagementLevel(score) {
        if (score >= 80) return 'high';
        if (score >= 60) return 'medium';
        return 'low';
    }
}

// AI Title Generator using Anthropic API
class AITitleGenerator {
    constructor() {
        this.apiEndpoint = 'https://api.anthropic.com/v1/messages';
        this.model = 'claude-sonnet-4-20250514';
    }

    async generateTitles(topic, keywords, style) {
        const stylePrompts = {
            'how-to': 'how-to guides and instructional titles',
            'list': 'list-based titles (e.g., "10 Ways...", "5 Tips...")',
            'question': 'question-based titles that provoke curiosity',
            'mixed': 'a mix of how-to, list, and question formats'
        };

        const prompt = `Generate exactly 10 SEO-friendly, engaging blog titles about "${topic}".
${keywords ? `Additional keywords to incorporate: ${keywords}` : ''}

Style focus: ${stylePrompts[style]}

Requirements:
- Each title must be catchy, SEO-optimized, and engaging
- Titles should vary in length (40-70 characters ideal)
- Include power words that drive engagement
- Make them click-worthy while maintaining credibility
- Ensure diversity in structure and approach

Return ONLY a valid JSON array with exactly 10 objects in this format:
[
  {
    "title": "The title text",
    "length": number of characters,
    "style": "how-to" or "list" or "question",
    "engagementScore": number from 50-100
  }
]

No explanations, no markdown, just the JSON array.`;

        try {
            const response = await fetch(this.apiEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    model: this.model,
                    max_tokens: 1000,
                    messages: [
                        { role: 'user', content: prompt }
                    ]
                })
            });

            if (!response.ok) {
                throw new Error(`API Error: ${response.status}`);
            }

            const data = await response.json();
            const textContent = data.content.find(item => item.type === 'text')?.text || '';
            
            // Parse JSON from response
            const jsonMatch = textContent.match(/\[[\s\S]*\]/);
            if (!jsonMatch) {
                throw new Error('Invalid response format from AI');
            }

            const titles = JSON.parse(jsonMatch[0]);
            
            // Validate and ensure we have 10 titles
            if (!Array.isArray(titles) || titles.length === 0) {
                throw new Error('No titles generated');
            }

            // Ensure each title has required properties
            return titles.map(title => ({
                title: title.title || 'Untitled',
                length: title.length || title.title?.length || 0,
                style: title.style || style,
                engagementScore: title.engagementScore || Math.floor(Math.random() * 30) + 60
            }));

        } catch (error) {
            console.error('AI Generation Error:', error);
            // Fallback to template-based generation if API fails
            return this.generateFallbackTitles(topic, style);
        }
    }

    generateFallbackTitles(topic, style) {
        const templates = {
            'how-to': [
                `How to Master ${topic} in 2026`,
                `The Complete Guide to ${topic}`,
                `How to Get Started with ${topic}`,
                `${topic}: A Step-by-Step Tutorial`,
                `How to Improve Your ${topic} Skills`
            ],
            'list': [
                `10 Essential ${topic} Tips You Need to Know`,
                `7 ${topic} Strategies That Actually Work`,
                `5 Common ${topic} Mistakes to Avoid`,
                `15 ${topic} Hacks for Beginners`,
                `The Top 12 ${topic} Tools in 2026`
            ],
            'question': [
                `What is ${topic}? Everything You Need to Know`,
                `Why is ${topic} Important in 2026?`,
                `Is ${topic} Right for You?`,
                `What Are the Best ${topic} Practices?`,
                `How Does ${topic} Actually Work?`
            ]
        };

        let titles = [];
        
        if (style === 'mixed') {
            titles = [
                ...templates['how-to'].slice(0, 3),
                ...templates['list'].slice(0, 4),
                ...templates['question'].slice(0, 3)
            ];
        } else {
            titles = templates[style] || templates['how-to'];
            // Add more variations if needed
            while (titles.length < 10) {
                titles.push(`${topic}: Essential Insights and Strategies`);
            }
        }

        return titles.slice(0, 10).map(title => ({
            title: title,
            length: title.length,
            style: this.detectStyle(title),
            engagementScore: Math.floor(Math.random() * 30) + 60
        }));
    }

    detectStyle(title) {
        const lowerTitle = title.toLowerCase();
        if (lowerTitle.includes('how to') || lowerTitle.includes('guide')) return 'how-to';
        if (/\d+/.test(title)) return 'list';
        if (lowerTitle.includes('?')) return 'question';
        return 'how-to';
    }
}

// Main Application Controller
class TitleGeneratorApp {
    constructor() {
        this.db = new TitleDatabase();
        this.aiGenerator = new AITitleGenerator();
        this.currentTitles = [];
        
        this.init();
    }

    init() {
        this.cacheElements();
        this.attachEventListeners();
        this.updateStats();
        this.loadStoredTitles();
    }

    cacheElements() {
        this.form = document.getElementById('titleForm');
        this.topicInput = document.getElementById('topic');
        this.keywordsInput = document.getElementById('keywords');
        this.generateBtn = document.getElementById('generateBtn');
        this.clearBtn = document.getElementById('clearBtn');
        this.loading = document.getElementById('loading');
        this.results = document.getElementById('results');
        this.titlesList = document.getElementById('titlesList');
        this.errorMsg = document.getElementById('errorMsg');
        this.styleFilter = document.getElementById('styleFilter');
        this.engagementFilter = document.getElementById('engagementFilter');
        
        // Stats
        this.totalGeneratedEl = document.getElementById('totalGenerated');
        this.totalTopicsEl = document.getElementById('totalTopics');
        this.avgScoreEl = document.getElementById('avgScore');
    }

    attachEventListeners() {
        this.form.addEventListener('submit', (e) => this.handleGenerate(e));
        this.clearBtn.addEventListener('click', () => this.clearResults());
        this.styleFilter.addEventListener('change', () => this.filterTitles());
        this.engagementFilter.addEventListener('change', () => this.filterTitles());
    }

    async handleGenerate(e) {
        e.preventDefault();
        
        const topic = this.topicInput.value.trim();
        const keywords = this.keywordsInput.value.trim();
        const style = document.querySelector('input[name="style"]:checked').value;

        if (!topic) {
            this.showError('Please enter a topic or keywords');
            return;
        }

        this.hideError();
        this.showLoading();
        this.generateBtn.disabled = true;

        try {
            // Simulate minimum loading time for UX
            const [titles] = await Promise.all([
                this.aiGenerator.generateTitles(topic, keywords, style),
                new Promise(resolve => setTimeout(resolve, 1500))
            ]);

            this.currentTitles = titles.map(titleData => ({
                ...titleData,
                topic: topic,
                keywords: keywords
            }));

            // Save to database
            this.currentTitles.forEach(title => this.db.addTitle(title));

            this.displayTitles(this.currentTitles);
            this.updateStats();
            this.hideLoading();
            this.showResults();

        } catch (error) {
            console.error('Generation error:', error);
            this.showError('Failed to generate titles. Please try again.');
            this.hideLoading();
        } finally {
            this.generateBtn.disabled = false;
        }
    }

    displayTitles(titles) {
        this.titlesList.innerHTML = '';
        
        if (titles.length === 0) {
            this.titlesList.innerHTML = '<p style="text-align: center; color: var(--text-muted); padding: 2rem;">No titles match your filters.</p>';
            return;
        }

        titles.forEach((titleData, index) => {
            const titleEl = this.createTitleElement(titleData, index);
            this.titlesList.appendChild(titleEl);
        });
    }

    createTitleElement(titleData, index) {
        const div = document.createElement('div');
        div.className = 'title-item';
        
        const engagementLevel = this.db.getEngagementLevel(titleData.engagementScore);
        const scoreClass = `score-${engagementLevel}`;

        div.innerHTML = `
            <div class="title-text">
                <span>${titleData.title}</span>
                <button class="copy-btn" data-title="${titleData.title}">
                    📋 Copy
                </button>
            </div>
            <div class="title-meta">
                <div class="meta-item">
                    <span>📏</span>
                    <span>${titleData.length} chars</span>
                </div>
                <div class="meta-item">
                    <span>✨</span>
                    <span>${this.formatStyle(titleData.style)}</span>
                </div>
                <div class="meta-item">
                    <span class="engagement-score ${scoreClass}">
                        ${titleData.engagementScore} Engagement
                    </span>
                </div>
            </div>
        `;

        // Add copy functionality
        const copyBtn = div.querySelector('.copy-btn');
        copyBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            this.copyToClipboard(titleData.title, copyBtn);
        });

        return div;
    }

    formatStyle(style) {
        const styleMap = {
            'how-to': 'How-to',
            'list': 'List',
            'question': 'Question'
        };
        return styleMap[style] || style;
    }

    async copyToClipboard(text, button) {
        try {
            await navigator.clipboard.writeText(text);
            const originalText = button.textContent;
            button.textContent = '✓ Copied!';
            button.classList.add('copied');
            
            setTimeout(() => {
                button.textContent = originalText;
                button.classList.remove('copied');
            }, 2000);
        } catch (error) {
            console.error('Copy failed:', error);
        }
    }

    filterTitles() {
        const styleFilter = this.styleFilter.value;
        const engagementFilter = this.engagementFilter.value;

        let filtered = [...this.currentTitles];

        if (styleFilter !== 'all') {
            filtered = filtered.filter(t => t.style === styleFilter);
        }

        if (engagementFilter !== 'all') {
            filtered = filtered.filter(t => 
                this.db.getEngagementLevel(t.engagementScore) === engagementFilter
            );
        }

        this.displayTitles(filtered);
    }

    loadStoredTitles() {
        const storedTitles = this.db.getTitles();
        if (storedTitles.length > 0) {
            // Load last 10 titles
            this.currentTitles = storedTitles.slice(-10);
            if (this.currentTitles.length > 0) {
                this.displayTitles(this.currentTitles);
                this.showResults();
            }
        }
    }

    updateStats() {
        const stats = this.db.getStats();
        
        this.animateValue(this.totalGeneratedEl, parseInt(this.totalGeneratedEl.textContent) || 0, stats.totalGenerated, 1000);
        this.animateValue(this.totalTopicsEl, parseInt(this.totalTopicsEl.textContent) || 0, stats.totalTopics, 1000);
        this.animateValue(this.avgScoreEl, parseInt(this.avgScoreEl.textContent) || 0, stats.avgScore, 1000);
    }

    animateValue(element, start, end, duration) {
        const range = end - start;
        const increment = range / (duration / 16);
        let current = start;
        
        const timer = setInterval(() => {
            current += increment;
            if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
                current = end;
                clearInterval(timer);
            }
            element.textContent = Math.round(current);
        }, 16);
    }

    clearResults() {
        if (confirm('Clear all generated titles from database?')) {
            this.db.clearAll();
            this.currentTitles = [];
            this.titlesList.innerHTML = '';
            this.results.classList.remove('active');
            this.updateStats();
            this.form.reset();
        }
    }

    showLoading() {
        this.loading.classList.add('active');
        this.results.classList.remove('active');
    }

    hideLoading() {
        this.loading.classList.remove('active');
    }

    showResults() {
        this.results.classList.add('active');
    }

    showError(message) {
        this.errorMsg.textContent = message;
        this.errorMsg.classList.add('active');
        setTimeout(() => this.hideError(), 5000);
    }

    hideError() {
        this.errorMsg.classList.remove('active');
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new TitleGeneratorApp();
});
