# Deployment & Setup Guide

## Quick Start (Frontend Only)

The simplest way to run the application is using just the frontend:

### Option 1: Direct Browser (No Server Required)

1. **Download files:**
   - `index.html`
   - `app.js`

2. **Open in browser:**
   ```bash
   # Simply double-click index.html
   # Or drag it into your browser
   ```

3. **That's it!** The app uses:
   - LocalStorage for database
   - Client-side AI integration
   - No backend server needed

### Option 2: Simple HTTP Server

```bash
# Using Python
python -m http.server 8000

# Using Node.js
npx http-server -p 8000

# Using PHP
php -S localhost:8000

# Then visit: http://localhost:8000
```

## Full Stack Setup (Optional)

### Prerequisites

- Node.js 16+ and npm
- PostgreSQL 12+ (optional)
- Anthropic API key (optional - has fallback)

### Step 1: Install Dependencies

```bash
npm install
```

### Step 2: Environment Setup

```bash
# Copy environment template
cp .env.example .env

# Edit .env with your credentials
nano .env
```

Add your Anthropic API key:
```env
ANTHROPIC_API_KEY=sk-ant-your-key-here
PORT=3000
NODE_ENV=development
```

### Step 3: Database Setup (Optional)

#### Using PostgreSQL:

```bash
# Create database
createdb blog_titles_db

# Run schema
psql blog_titles_db < schema.sql

# Update .env with database credentials
```

#### Using In-Memory (Default):

No setup needed! The server uses in-memory storage by default.

### Step 4: Start Server

```bash
# Production
npm start

# Development (with auto-reload)
npm run dev
```

Server runs at: `http://localhost:3000`

## Cloud Deployment

### Deploying to Heroku

```bash
# Login to Heroku
heroku login

# Create app
heroku create your-app-name

# Add PostgreSQL
heroku addons:create heroku-postgresql:hobby-dev

# Set environment variables
heroku config:set ANTHROPIC_API_KEY=your-key

# Deploy
git push heroku main

# Open app
heroku open
```

### Deploying to Vercel

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Set environment variables in Vercel dashboard
# ANTHROPIC_API_KEY=your-key
```

### Deploying to Netlify

1. **Connect GitHub repository**
2. **Build settings:**
   - Build command: `npm run build`
   - Publish directory: `public`
3. **Environment variables:**
   - Add `ANTHROPIC_API_KEY`

### Deploying to AWS

#### Using AWS Elastic Beanstalk:

```bash
# Install EB CLI
pip install awsebcli

# Initialize
eb init

# Create environment
eb create production

# Deploy
eb deploy
```

#### Using AWS Lambda + API Gateway:

See `serverless.yml` for configuration (create if needed)

### Deploying to Google Cloud

```bash
# Install gcloud CLI
gcloud init

# Deploy
gcloud app deploy

# View
gcloud app browse
```

## Docker Deployment

### Build Image

```bash
docker build -t ai-title-generator .
```

### Run Container

```bash
docker run -p 3000:3000 \
  -e ANTHROPIC_API_KEY=your-key \
  -e NODE_ENV=production \
  ai-title-generator
```

### Docker Compose

```bash
docker-compose up -d
```

## Production Checklist

### Security
- [ ] API keys in environment variables
- [ ] HTTPS enabled
- [ ] CORS configured properly
- [ ] Rate limiting enabled
- [ ] Input validation active
- [ ] SQL injection prevention (if using SQL)

### Performance
- [ ] Response caching enabled
- [ ] Static assets compressed
- [ ] CDN configured (if needed)
- [ ] Database indexed
- [ ] Connection pooling (if using DB)

### Monitoring
- [ ] Error logging configured
- [ ] Performance monitoring
- [ ] Uptime monitoring
- [ ] API usage tracking
- [ ] Analytics integrated

### Backup
- [ ] Database backups scheduled
- [ ] Code repository backed up
- [ ] Environment variables documented
- [ ] Disaster recovery plan

## Environment Variables Reference

```env
# Required
ANTHROPIC_API_KEY=sk-ant-your-key-here

# Optional
PORT=3000
NODE_ENV=production
DATABASE_URL=postgresql://...
API_RATE_LIMIT=100
API_TIMEOUT=30000
LOG_LEVEL=info
```

## API Endpoints

### POST /api/generate
Generate new titles

**Request:**
```json
{
  "topic": "artificial intelligence",
  "keywords": "machine learning, AI",
  "style": "how-to"
}
```

**Response:**
```json
{
  "success": true,
  "titles": [...],
  "stats": {...}
}
```

### GET /api/titles
Get titles with filters

**Query params:**
- `style`: how-to, list, question
- `engagement`: high, medium, low
- `limit`: number of results

### GET /api/stats
Get statistics

**Response:**
```json
{
  "success": true,
  "stats": {
    "totalGenerated": 150,
    "totalTopics": 25,
    "avgScore": 78
  }
}
```

### DELETE /api/clear
Clear database

## Troubleshooting

### Issue: API Key Not Working

**Solution:**
1. Verify API key is correct
2. Check environment variables are loaded
3. Ensure no extra spaces in .env file
4. Restart server after changing .env

### Issue: Database Connection Failed

**Solution:**
1. Check PostgreSQL is running
2. Verify credentials in .env
3. Test connection: `psql -U user -d database`
4. Check firewall settings

### Issue: CORS Errors

**Solution:**
1. Check CORS middleware configuration
2. Verify frontend URL in CORS whitelist
3. Check browser console for details
4. Test with CORS disabled (dev only)

### Issue: Titles Not Generating

**Solution:**
1. Check AI API key is valid
2. Verify internet connection
3. Check API rate limits
4. Review server logs for errors
5. Test with fallback generation

### Issue: Slow Performance

**Solution:**
1. Enable response caching
2. Add database indexes
3. Optimize queries
4. Use connection pooling
5. Consider CDN for static assets

## Performance Optimization

### Caching Strategy

```javascript
// Add caching middleware
const cache = require('memory-cache');

app.get('/api/titles', (req, res) => {
  const cacheKey = JSON.stringify(req.query);
  const cached = cache.get(cacheKey);
  
  if (cached) {
    return res.json(cached);
  }
  
  // ... fetch data ...
  
  cache.put(cacheKey, data, 60000); // 1 minute
  res.json(data);
});
```

### Database Optimization

```sql
-- Add indexes
CREATE INDEX idx_titles_composite 
ON titles(style, engagement_score, created_at);

-- Use materialized views for stats
CREATE MATERIALIZED VIEW stats_cache AS
SELECT * FROM title_statistics;

-- Refresh periodically
REFRESH MATERIALIZED VIEW stats_cache;
```

## Monitoring Setup

### Using PM2 (Production)

```bash
# Install PM2
npm install -g pm2

# Start app
pm2 start server.js --name "title-generator"

# Monitor
pm2 monit

# Logs
pm2 logs

# Auto-restart on crash
pm2 startup
pm2 save
```

### Using Winston (Logging)

```javascript
const winston = require('winston');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ 
      filename: 'error.log', 
      level: 'error' 
    }),
    new winston.transports.File({ 
      filename: 'combined.log' 
    })
  ]
});

// Use in code
logger.info('Title generated', { topic, count: 10 });
logger.error('API error', { error: err.message });
```

## Testing

### Manual Testing

1. Test title generation with various topics
2. Verify all style options work
3. Test filters and sorting
4. Check copy functionality
5. Validate statistics updates
6. Test on different browsers
7. Test on mobile devices

### API Testing (using curl)

```bash
# Generate titles
curl -X POST http://localhost:3000/api/generate \
  -H "Content-Type: application/json" \
  -d '{"topic":"AI","style":"how-to"}'

# Get titles
curl http://localhost:3000/api/titles?style=list&limit=5

# Get stats
curl http://localhost:3000/api/stats

# Clear database
curl -X DELETE http://localhost:3000/api/clear
```

## Maintenance

### Regular Tasks

**Daily:**
- Monitor error logs
- Check API usage
- Verify uptime

**Weekly:**
- Review performance metrics
- Check disk space
- Update dependencies (security)

**Monthly:**
- Database optimization
- Backup verification
- Security audit

## Support & Resources

- **Documentation:** This README
- **API Docs:** See API Endpoints section
- **Issues:** Check console logs
- **Updates:** Pull latest from repository

---

**Need Help?** Review the troubleshooting section or check server logs for detailed error messages.
