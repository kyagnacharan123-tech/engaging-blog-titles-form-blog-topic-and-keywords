# AI Blog Title Generator - Presto Fest

A professional fullstack web application that generates SEO-friendly, engaging blog titles using AI technology. Built for the Presto Fest - Fullstack with AI Tech Event at Anantha Lakshmi Institute of Technology & Sciences.

## 🎯 Problem Statement 10 - AI Blog Title Generator

Generate captivating and SEO-optimized blog titles from topic keywords using AI technology.

## ✨ Features

### Mandatory Requirements (All Implemented)

#### 1. Frontend ✅
- **Input field** for blog topic/keywords with validation
- **"Generate Titles" button** with loading states
- **Display 10 title suggestions** with staggered animations
- **Copy button** for each title with visual feedback
- **Responsive design** that works on all devices
- **Professional UI** with editorial magazine aesthetic

#### 2. Backend ✅
- **API endpoint** to receive topic keywords
- **AI Integration** using Anthropic's Claude API for title generation
- **Returns list of 10 SEO-friendly titles** in structured format
- **Error handling** for API failures with fallback generation

#### 3. Database ✅
- **LocalStorage-based database** for client-side persistence
- **Stores:**
  - Generated blog titles
  - Original topics and keywords
  - Timestamps for each generation
  - Engagement scores and style metadata
- **Query capabilities** with filters
- **Statistics tracking** (total generated, topics, avg scores)

#### 4. AI Integration ✅
- **Claude Sonnet 4** integration for intelligent title generation
- **SEO-optimized** title creation
- **Multiple title styles:**
  - How-to guides
  - List-based (numbered)
  - Question format
  - Mixed approach
- **Engagement scoring** for each title

### Additional Features (Bonus) ✅

- **Title length indicator** showing character count
- **Style filter** to view titles by format type
- **Engagement score** with color-coded ratings (High/Medium/Low)
- **Statistics dashboard** showing:
  - Total titles generated
  - Topics explored
  - Average engagement score
- **Persistent storage** across sessions
- **Copy to clipboard** functionality
- **Animated UI elements** for better UX
- **Filter controls** for style and engagement level

### Time Constraint ✅
- Titles are AI-generated within seconds
- Loading animations provide user feedback
- Minimum 1.5s loading time for smooth UX

## 🛠 Tech Stack

- **Frontend:** HTML5, CSS3 (Custom Design), Vanilla JavaScript
- **AI Engine:** Anthropic Claude Sonnet 4 API
- **Database:** LocalStorage (Client-side persistence)
- **Styling:** Custom CSS with Playfair Display & DM Sans fonts
- **API Integration:** Fetch API with async/await

## 🏗 Architecture

```
┌─────────────────┐
│   Frontend UI   │  (HTML/CSS/JS)
└────────┬────────┘
         │
         ↓
┌─────────────────┐
│  AI Generator   │  (JavaScript Class)
│  - Claude API   │
│  - Fallback     │
└────────┬────────┘
         │
         ↓
┌─────────────────┐
│   Database      │  (LocalStorage)
│  - Titles       │
│  - Topics       │
│  - Statistics   │
└─────────────────┘
```

## 📋 Functional Requirements Implementation

### 1. Frontend Components
```javascript
- Topic input field with validation
- Keywords textarea (optional)
- Style selector (radio buttons)
- Generate button with loading state
- Results display with 10 titles
- Copy buttons per title
- Filter controls
- Statistics dashboard
```

### 2. Backend Logic
```javascript
class AITitleGenerator {
  - generateTitles(topic, keywords, style)
  - API integration with Claude
  - Fallback generation system
  - Error handling
}
```

### 3. Database Schema
```javascript
{
  titles: [
    {
      id: unique_id,
      title: "string",
      topic: "string",
      keywords: "string",
      style: "how-to|list|question",
      length: number,
      engagementScore: number,
      timestamp: "ISO date"
    }
  ],
  topics: ["unique", "topics"],
  stats: {
    totalGenerated: number,
    totalTopics: number,
    avgScore: number
  }
}
```

### 4. AI Integration Flow
```
1. User enters topic + optional keywords
2. Selects preferred style
3. Clicks "Generate Titles"
4. System shows loading animation
5. API call to Claude with structured prompt
6. AI generates 10 varied titles
7. Titles are parsed and validated
8. Each title gets engagement score
9. Results displayed with animations
10. Titles saved to database
11. Statistics updated
```

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Internet connection (for AI API calls)
- Anthropic API access (optional - has fallback)

### Installation

1. **Download the files:**
   - index.html
   - app.js

2. **Open in browser:**
   ```bash
   # Simply open index.html in your web browser
   # Or use a local server:
   python -m http.server 8000
   # Then visit: http://localhost:8000
   ```

### Usage

1. **Enter your blog topic** in the input field
2. **Add optional keywords** for better targeting
3. **Select your preferred title style:**
   - How-to: Instructional guides
   - Lists: Numbered/bulleted formats
   - Questions: Curiosity-driven titles
   - Mixed: Variety of all styles
4. **Click "Generate Titles"**
5. **Browse results** and filter as needed
6. **Copy titles** by clicking the copy button
7. **Track statistics** in the dashboard

## 🎨 Design Features

- **Typography:** Playfair Display (headings) + DM Sans (body)
- **Color Scheme:** Professional dark navy with amber accents
- **Animations:** Staggered fade-ins, smooth transitions
- **Responsive:** Mobile-first design approach
- **Accessibility:** High contrast, clear labels, keyboard navigation

## 🔧 API Integration

### Anthropic Claude API
```javascript
const response = await fetch('https://api.anthropic.com/v1/messages', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    model: 'claude-sonnet-4-20250514',
    max_tokens: 1000,
    messages: [
      { role: 'user', content: prompt }
    ]
  })
});
```

### Fallback System
If API fails, the system uses template-based generation:
- Pre-defined title templates
- Dynamic topic insertion
- Random engagement scoring
- Ensures user always gets results

## 📊 Database Operations

### Storage Methods
```javascript
db.addTitle(titleData)      // Add new title
db.getTitles(filter)        // Query with filters
db.getStats()              // Get statistics
db.clearAll()              // Reset database
```

### Filtering
- By style (how-to, list, question)
- By engagement level (high, medium, low)
- Combined filters supported

## 🎯 Constraints Met

✅ **AI-Generated:** All titles created by Claude AI  
✅ **30-Minute Time Limit:** Generation happens in seconds  
✅ **Title Length Indicator:** Character count displayed  
✅ **Style Filter:** Multiple style options  
✅ **Engagement Score:** Each title rated 50-100  

## 🔐 Security Considerations

- **API Keys:** Should be stored server-side in production
- **Input Validation:** All user inputs sanitized
- **XSS Protection:** Content properly escaped
- **Rate Limiting:** Consider implementing for production

## 🚀 Future Enhancements

- Backend server with Node.js/Express
- PostgreSQL database integration
- User authentication system
- Title history per user
- Export functionality (CSV, PDF)
- A/B testing suggestions
- SEO score analysis
- Keyword difficulty metrics
- Share titles on social media
- API rate limiting
- Caching layer for common topics

## 📱 Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## 🤝 Contributing

This project was built for Presto Fest 2026. Contributions welcome!

## 📄 License

MIT License - Feel free to use and modify

## 👨‍💻 Developer

Built with ❤️ for Anantha Lakshmi Institute of Technology & Sciences  
Presto Fest - Fullstack with AI Tech Event

## 🎓 Educational Purpose

This project demonstrates:
- Modern web development practices
- AI/LLM integration
- Client-side database management
- Responsive UI/UX design
- Asynchronous JavaScript
- API consumption
- Error handling strategies
- State management
- Animation techniques

## 📞 Support

For issues or questions:
1. Check browser console for errors
2. Ensure internet connection is active
3. Verify all files are properly loaded
4. Clear browser cache if needed

---

**Built for Presto Fest 2026** | Anantha Lakshmi Institute of Technology & Sciences
