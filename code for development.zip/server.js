// Backend Server - Optional Node.js Implementation
// This provides a full backend with database support

const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// In-memory database (replace with PostgreSQL in production)
let database = {
    titles: [],
    topics: [],
    stats: {
        totalGenerated: 0,
        totalTopics: 0,
        avgScore: 0
    }
};

// AI Integration Module
class AIService {
    constructor() {
        this.apiKey = process.env.ANTHROPIC_API_KEY;
        this.apiEndpoint = 'https://api.anthropic.com/v1/messages';
        this.model = 'claude-sonnet-4-20250514';
    }

    async generateTitles(topic, keywords, style) {
        const stylePrompts = {
            'how-to': 'how-to guides and instructional titles',
            'list': 'list-based titles (e.g., "10 Ways...", "5 Tips...")',
            'question': 'question-based titles that provoke curiosity',
            'mixed': 'a mix of how-to, list, and question formats'
        };

        const prompt = `Generate exactly 10 SEO-friendly, engaging blog titles about "${topic}".
${keywords ? `Additional keywords to incorporate: ${keywords}` : ''}

Style focus: ${stylePrompts[style]}

Requirements:
- Each title must be catchy, SEO-optimized, and engaging
- Titles should vary in length (40-70 characters ideal)
- Include power words that drive engagement
- Make them click-worthy while maintaining credibility
- Ensure diversity in structure and approach

Return ONLY a valid JSON array with exactly 10 objects in this format:
[
  {
    "title": "The title text",
    "length": number of characters,
    "style": "how-to" or "list" or "question",
    "engagementScore": number from 50-100
  }
]

No explanations, no markdown, just the JSON array.`;

        try {
            const response = await fetch(this.apiEndpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-api-key': this.apiKey,
                    'anthropic-version': '2023-06-01'
                },
                body: JSON.stringify({
                    model: this.model,
                    max_tokens: 1000,
                    messages: [
                        { role: 'user', content: prompt }
                    ]
                })
            });

            if (!response.ok) {
                throw new Error(`API Error: ${response.status}`);
            }

            const data = await response.json();
            const textContent = data.content.find(item => item.type === 'text')?.text || '';
            
            const jsonMatch = textContent.match(/\[[\s\S]*\]/);
            if (!jsonMatch) {
                throw new Error('Invalid response format');
            }

            const titles = JSON.parse(jsonMatch[0]);
            return titles;

        } catch (error) {
            console.error('AI Service Error:', error);
            throw error;
        }
    }
}

// Database Service
class DatabaseService {
    addTitle(titleData) {
        titleData.id = Date.now() + Math.random();
        titleData.timestamp = new Date().toISOString();
        database.titles.push(titleData);
        
        // Update stats
        database.stats.totalGenerated = database.titles.length;
        
        if (!database.topics.includes(titleData.topic)) {
            database.topics.push(titleData.topic);
            database.stats.totalTopics = database.topics.length;
        }
        
        const totalScore = database.titles.reduce((sum, t) => sum + t.engagementScore, 0);
        database.stats.avgScore = Math.round(totalScore / database.titles.length);
        
        return titleData;
    }

    getTitles(filter = {}) {
        let titles = [...database.titles];
        
        if (filter.style && filter.style !== 'all') {
            titles = titles.filter(t => t.style === filter.style);
        }
        
        if (filter.engagement) {
            const level = filter.engagement;
            titles = titles.filter(t => {
                const score = t.engagementScore;
                if (level === 'high') return score >= 80;
                if (level === 'medium') return score >= 60 && score < 80;
                if (level === 'low') return score < 60;
                return true;
            });
        }
        
        if (filter.limit) {
            titles = titles.slice(-filter.limit);
        }
        
        return titles;
    }

    getStats() {
        return database.stats;
    }

    clearAll() {
        database = {
            titles: [],
            topics: [],
            stats: {
                totalGenerated: 0,
                totalTopics: 0,
                avgScore: 0
            }
        };
        return { success: true };
    }
}

// Initialize services
const aiService = new AIService();
const dbService = new DatabaseService();

// API Routes

// Generate titles
app.post('/api/generate', async (req, res) => {
    try {
        const { topic, keywords, style } = req.body;

        if (!topic) {
            return res.status(400).json({ 
                error: 'Topic is required' 
            });
        }

        // Generate titles using AI
        const titles = await aiService.generateTitles(topic, keywords, style);

        // Save to database
        const savedTitles = titles.map(title => 
            dbService.addTitle({
                ...title,
                topic,
                keywords
            })
        );

        res.json({
            success: true,
            titles: savedTitles,
            stats: dbService.getStats()
        });

    } catch (error) {
        console.error('Generation error:', error);
        res.status(500).json({ 
            error: 'Failed to generate titles',
            message: error.message 
        });
    }
});

// Get titles with filters
app.get('/api/titles', (req, res) => {
    try {
        const filter = {
            style: req.query.style,
            engagement: req.query.engagement,
            limit: parseInt(req.query.limit) || undefined
        };

        const titles = dbService.getTitles(filter);
        
        res.json({
            success: true,
            titles,
            count: titles.length
        });

    } catch (error) {
        console.error('Query error:', error);
        res.status(500).json({ 
            error: 'Failed to retrieve titles' 
        });
    }
});

// Get statistics
app.get('/api/stats', (req, res) => {
    try {
        const stats = dbService.getStats();
        res.json({
            success: true,
            stats
        });
    } catch (error) {
        console.error('Stats error:', error);
        res.status(500).json({ 
            error: 'Failed to retrieve statistics' 
        });
    }
});

// Clear database
app.delete('/api/clear', (req, res) => {
    try {
        const result = dbService.clearAll();
        res.json({
            success: true,
            message: 'Database cleared successfully'
        });
    } catch (error) {
        console.error('Clear error:', error);
        res.status(500).json({ 
            error: 'Failed to clear database' 
        });
    }
});

// Health check
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'healthy',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

// Serve frontend
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Server error:', err);
    res.status(500).json({ 
        error: 'Internal server error',
        message: process.env.NODE_ENV === 'development' ? err.message : undefined
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`
🚀 AI Blog Title Generator Server Running
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📍 Server: http://localhost:${PORT}
🔧 Environment: ${process.env.NODE_ENV || 'development'}
🤖 AI Model: Claude Sonnet 4
📊 Database: In-Memory (Development)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    `);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM received. Shutting down gracefully...');
    server.close(() => {
        console.log('Server closed');
        process.exit(0);
    });
});

module.exports = app;
